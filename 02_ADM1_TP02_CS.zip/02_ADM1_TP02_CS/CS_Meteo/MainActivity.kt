package com.meteo

import android.os.Bundle
import android.view.View
import android.widget.CompoundButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.meteo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var amb : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        initGraphique()
    }
    private fun initGraphique() {
        amb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(amb.root)
        ajouterEcouteurs()
        actualiserPluie(amb.chNuages.isChecked)
    }
    private fun ajouterEcouteurs() {
        amb.btnAfficher.setOnClickListener(object: View.OnClickListener{
            override fun onClick(p0: View?) {
                afficher()
            }
        })
       amb.chNuages.setOnCheckedChangeListener ( object: CompoundButton.OnCheckedChangeListener{
           override fun onCheckedChanged(p0: CompoundButton, p1: Boolean) {
               actualiserPluie(p1)
           }
       } )
    }
    private fun afficher() {
        if(amb.chSoleil.isChecked ||   amb.chNuages.isChecked) {
            var saison = "Saison: "

            //Méthode1
            saison += when (amb.rdgSaison.checkedRadioButtonId) {
                R.id.rdAutomne -> getString(R.string.automne)
                R.id.rdHivers -> getString(R.string.hivers)
                R.id.rdPrintemps -> getString(R.string.printemps)
                R.id.rdEte -> getString(R.string.ete)
                else -> "Inconnue"
            }
            var ciel = "Ciel: "
            ciel += if (amb.chSoleil.isChecked) "Soleil " else ""
            if (amb.chSoleil.isChecked)
                ciel += if (amb.chNuages.isChecked) "+ Nuages " else ""
            else
                ciel += if (amb.chNuages.isChecked) "Nuages " else ""
            ciel += if (amb.chPluie.isChecked) "+ Pluie " else ""
            Toast.makeText(this, "$saison \n $ciel", Toast.LENGTH_LONG).show()
        }else
            Toast.makeText(this, "Cochez Soleil ou Nuages SVP!", Toast.LENGTH_LONG).show()
    }
    private fun actualiserPluie(isNuages: Boolean) {
        if(isNuages){
            amb.chPluie.isEnabled=true
        }else{
            amb.chPluie.isEnabled=false
            amb.chPluie.isChecked=false
        }
    }
}