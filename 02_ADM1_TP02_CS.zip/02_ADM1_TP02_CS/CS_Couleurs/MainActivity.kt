package com.couleurs

import android.graphics.Color
import android.os.Bundle
import android.widget.SeekBar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.couleurs.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var amb : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initGraphique()
    }
    private fun initGraphique() {
        amb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(amb.root)
        ajouterEcouteurs()
        appliquer()
    }
    private fun ajouterEcouteurs() {
        val ecouteur= object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(
                p0: SeekBar?,
                p1: Int,
                p2: Boolean
            ) {
                appliquer()
            }
            override fun onStartTrackingTouch(p0: SeekBar?) {
            }
            override fun onStopTrackingTouch(p0: SeekBar?) {
            }
        }
        amb.seekAlpha.setOnSeekBarChangeListener(ecouteur)
        amb.seekRouge.setOnSeekBarChangeListener(ecouteur)
        amb.seekVert.setOnSeekBarChangeListener(ecouteur)
        amb.seekBleu.setOnSeekBarChangeListener(ecouteur)
    }
    private fun appliquer() {
        val a=amb.seekAlpha.progress
        val r=amb.seekRouge.progress
        val v=amb.seekVert.progress
        val b=amb.seekBleu.progress
        amb.tvARGB.text="ARGB($a,$r;$v,$b)"
        amb.tvApercu.setBackgroundColor(Color.argb(a,r,v,b))
        var nomCouleur="Aperçu "
        nomCouleur+=when{
            a>0&&r>0&&r==v&&b==0->": Jaune"
            a>0&&r>0&&r==b&&v==0->": Magenta"
            a>0&&r==0&&v>0&&v==b->": Cyan"
            else->""
        }
        amb.tvApercu.text=nomCouleur
    }
}

