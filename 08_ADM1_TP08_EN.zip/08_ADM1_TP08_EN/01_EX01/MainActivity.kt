package com.appel;

class MainActivity : AppCompatActivity() {	
    private lateinit var amb: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Centralisation totale
        initGraphique()
    }
    private fun initGraphique() {
        // 1. Initialisation du binding
        amb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(amb.root)        
        // 2. Initialisation des composants et événements
        ajouterEcouteur()
    }
    private fun ajouterEcouteur() {
        amb.btnAppeler.setOnClickListener {
            appeler()
        }
    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty()) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                appeler()
            }
        }
    }
    protected fun appeler() {
        val numero = amb.edNumero.text.toString()        
        if (numero.isNotBlank()) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), 101)
                return
            }     
            //Ajouter l'Intent implicite qui permet de faire l'appel			
        
		
		
        }
    }
}

