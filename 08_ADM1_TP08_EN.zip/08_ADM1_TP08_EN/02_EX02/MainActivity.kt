package com.sms;

class MainActivity : AppCompatActivity() {

    private lateinit var amb: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initGraphique()
    }

    private fun initGraphique() {
        // Initialisation du View Binding
        amb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(amb.root)
        
        ajouterEcouteur()
    }

    private fun ajouterEcouteur() {
        amb.btnEnvoyer.setOnClickListener {
            envoyer()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 102 && grantResults.isNotEmpty()) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                envoyer()
            }
        }
    }
	protected fun envoyer() {
        val numero = amb.edNumero.text.toString()
        val corps = amb.edCorps.text.toString()

        if (numero.length >= 8 && corps.isNotBlank()) {
            // Vérification des permissions (SMS et Phone State)
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE),
                    102
                )
                return
            }
			//Ajouter le code qui permet d'envoyer le SMS
           
		   
        } else {
            Toast.makeText(this, "Entrez le numéro et le corps SVP!", Toast.LENGTH_SHORT).show()
        }
    }
}
