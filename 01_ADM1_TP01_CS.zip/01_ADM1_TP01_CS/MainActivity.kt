package com.conversion.temp

import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.conversion.temp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var amb : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        initGraphique()


    }

    private fun initGraphique() {
        amb = ActivityMainBinding.inflate(layoutInflater)
        setContentView(amb.root)
        amb.etC.setText("25")
        ajouterEcouteurs()
    }

    private fun ajouterEcouteurs() {
        amb.btnCF.setOnClickListener { convertirCF() }
        amb.btnFC.setOnClickListener { convertirFC() }
    }
    private fun convertirCF() {
        if(amb.etC.text.toString().isNotEmpty()){
            var c:Float=amb.etC.text.toString().toFloat()
            var f:Float=(c*9/5)+32
            amb.etF.setText(f.toString())
            colorer()
        }else{
            amb.etF.text.clear()
            Toast.makeText(this,"Remplir °C SVP!", Toast.LENGTH_LONG).show()
        }

    }
    private fun convertirFC() {
        if(amb.etF.text.toString().isNotEmpty()){
            var f:Float=amb.etF.text.toString().toFloat()
            var c:Float=(f-32)*5/9
            amb.etC.setText(f.toString())
            colorer()
        }else{
            amb.etC.text.clear()
            Toast.makeText(this,"Remplir °F SVP!", Toast.LENGTH_LONG).show()
        }

    }

    private fun colorer() {
        if(amb.etC.text.toString().isNotEmpty()) {
            var c: Float = amb.etC.text.toString().toFloat()
            var (couleurTexte, couleurFond) = when {
                c <= 0 -> Pair(Color.WHITE, Color.BLACK)
                c <= 20 -> Pair(Color.BLUE, Color.WHITE)
                c <= 30 -> Pair(Color.YELLOW, Color.GREEN)
                else -> Pair(Color.RED, Color.GRAY) // Cas par défaut obligatoire pour l'assignation
            }
            amb.etC.setTextColor(couleurTexte)
            amb.etC.setBackgroundColor(couleurFond)
            amb.etF.setTextColor(couleurTexte)
            amb.etF.setBackgroundColor(couleurFond)
        }

    }
}


