package com.prixvignette

class Automobile(
    var matricule: String? = null,
    var type: Int = 0,       // 0 : Personne physique, 1 : Personne morale
    var puissance: Int = 0,
    var carburent: String? = null
) {

    // Équivalent du "static" en Java
    companion object {
        private val TARIF_PHYSIQUE = arrayOf(
            intArrayOf(60, 210, 385),
            intArrayOf(120, 270, 445)
        )
        private val TARIF_MORALE = arrayOf(
            intArrayOf(120, 270, 445),
            intArrayOf(240, 390, 565)
        )
    }

    val prix: Int
        get() {
            val iP = if (puissance <= 4) 0 else 1
            
            val iC = when (carburent?.lowercase()) {
                "essence" -> 0
                "diesel"  -> 1
                else      -> 2
            }

            return if (type == 0) {
                TARIF_PHYSIQUE[iP][iC]
            } else {
                TARIF_MORALE[iP][iC]
            }
        }
}
