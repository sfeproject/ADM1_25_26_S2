package com.imc

import kotlin.math.pow

class Personne(
    val poids: Float,
    val taille: Float,
    val age: Int
) {

    // Équivalent des constantes statiques en Java
    companion object {
        const val HOMME = 0
        const val FEMME = 1
    }

    /**
     * Calcule l'Indice de Masse Corporelle (IMC).
     * Utilise la fonction d'extension .pow() de Kotlin.
     */
    fun imc(): Double {
        return poids / taille.toDouble().pow(2.0)
    }

    /**
     * Calcule le poids idéal selon la formule de Lorentz.
     * En Kotlin, 'if' est une expression qui peut retourner une valeur.
     */
    fun getPoidsIdeal(estHomme: Boolean): Double {
        val tailleCm = taille * 100
        
        return if (estHomme) {
            tailleCm - 100 - (tailleCm - 150) / 4.0
        } else {
            tailleCm - 100 - (tailleCm - 150) / 2.5
        }
    }
}